<?php
$T_HOME = 'Houptsite';
$T_EDIT = 'Bearbeite';
$T_DONE = 'Spychere';
$T_SEARCH = 'Sueche';
$T_SEARCH_RESULTS = 'Suechergäbnis';
$T_LIST_OF_ALL_PAGES = 'Syteübersicht';
$T_RECENT_CHANGES = 'Letschti ändrige';
$T_LAST_CHANGED = 'zletscht gändert';
$T_HISTORY = 'Gschicht';
$T_RESTORE = 'Widrhärstelle';
$T_PASSWORD = 'Passwort';
$T_EDIT_SUMMARY = 'Zämefassig:';
$T_ERASE_COOKIE = 'Cookies entfärne';
$T_MOVE_TEXT = 'neui Bezeichnig:';
$T_CREATE_PAGE = 'Syte erstelle mit dem Name:';
$T_PROTECTED_READ = 'für die Inhaltsdarstellig bitte Passwort igäh: ';
$T_WRONG_PASSWORD = 'Passwort isch fählerhaft.';