<?php
$T_HOME = 'Hlavná strana';
$T_SYNTAX = 'Syntaxe';
$T_EDIT = 'Editovať';
$T_DONE = 'Uložiť zmeny';
$T_SEARCH = 'Hľadať';
$T_SEARCH_RESULTS = 'Výsledky hľadania';
$T_LIST_OF_ALL_PAGES = 'Zoznam všetkých stránok';
$T_RECENT_CHANGES = 'Posledné zmeny';
$T_LAST_CHANGED = 'Naposledy zmenené';
$T_HISTORY = 'História';
$T_RESTORE = 'Obnoviť';
$T_PASSWORD = 'Heslo';
$T_EDIT_SUMMARY = 'Zhrnutie úpravy:';
$T_ERASE_COOKIE = 'Zmazať cookies';
$T_MOVE_TEXT = 'Nové meno:';
$T_CREATE_PAGE = 'Vytvoriť stránku s názvom';
$T_PROTECTED_READ = 'Na zobrazenie obsahu stránok je potrebné zadať heslo: ';
$T_WRONG_PASSWORD = 'Zadané heslo nie je správne.';

$DATE_FORMAT = 'd. m. Y H:i';